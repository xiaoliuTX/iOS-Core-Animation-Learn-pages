Version 1.2

- Added support for loading SpriteKit texture atlasses in Xcode 5 and above
- Added LSImageView class to simplify use of sprites in UIKit apps

Version 1.1

- Added object subscripting access methods to LSImageMap
- Added fast enumeration support to LSImageMap
- Images in LSImageMap are now sorted alphabetically

Version 1.0.1

- Fixed crash when loading TexturePacker v2 sprite sheets

Version 1.0

- Initial release